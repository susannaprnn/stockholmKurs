# fhir.education.kursig#0.1.0: FHIR-utbildning – Kurs-IG2026

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Encounter](StructureDefinition-EducationEncounter.md)
* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [FHIR-utbildning – Kurs-IG2026](index.md)

### Examples

* [encounter-tolvan-1 (Encounter)](Encounter-encounter-tolvan-1.md)
* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
